function clickit(){
document.getElementById("submit").click();
}

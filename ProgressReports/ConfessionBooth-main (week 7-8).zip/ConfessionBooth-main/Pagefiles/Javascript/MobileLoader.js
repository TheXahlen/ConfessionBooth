function Mobile(){
if (screen.width <= 700) {
     document.location = "mobileindex.html";
}}


// Tried shortening refrences with these but it just didn't cooperate very well
//var cycledis = document.getElementById("cycle")
//var submitdis = document.getElementById("submit")
//var selector = document.getElementById("selector")

///file is not repurposed.

function Clicked(){
document.getElementById("submit").click();
}


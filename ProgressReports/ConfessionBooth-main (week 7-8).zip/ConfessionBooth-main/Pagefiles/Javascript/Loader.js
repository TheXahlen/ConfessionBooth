// anything that needs to happen on load happens in here
function Loader(){
//pass
}
////////////


Computer Science 481 Project
(This is a project that I have developed to submit data to a google spreadsheet
then retreive it as a json, it is then parsed using javascript and displayed with 
corresponding meta-data. The point is to create a simple site where users can submit confessions
into a database and view others submissions.)
